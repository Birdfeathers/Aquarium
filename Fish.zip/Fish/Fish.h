#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#ifndef FISH_H
#define FISH_H
using namespace std;

class Fish
{
    public:
        Fish(string Name, string Species, char Pattern);
        string getName();
        string getSpecies();
        char getPattern();
        int getHappiness();
        void changeHappiness(int amount);
        int getHealth();
        void changeHealth(int amount);
        int getFed();
        void changeFed(int amount);
        void resetFed();
        int getSize();
        string getOrientation();
        void printFoodType();
        bool matchFoodType(string Foodtype);
        int getFoodNumber();
    private:
       string name;
       string species;
       char pattern;
       int happiness;
       int health;
       int fed;
       int size;
       string orientation;
       string foodtype[7];
       int foodnumber;
};
#endif