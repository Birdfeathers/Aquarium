#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#include "User.h"

User :: User()
{
    money = 50;
    stamina = 10;
    drowsiness = -10;
}

int User :: getMoney()
{
    return money;
}

void User :: setMoney(int newmoney)
{
    money = newmoney;
}

int User :: getStamina()
{
    return stamina;
}

void User :: setStamina(int newStamina)
{
    stamina = newStamina;
}

int User :: getDrowsiness()
{
    return drowsiness;
}

void User :: setDrowsiness(int newDrowsiness)
{
    drowsiness = newDrowsiness;
}