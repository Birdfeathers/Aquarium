#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include "Tank.h"
#include "Fish.h"
#include "Item.h"
using namespace std;


int LookupFish(string name, vector <Fish>tankFish) // returns the fish's number
{
    for(int i = 0; i < tankFish.size(); i++)
    {
       if(tankFish[i].getName() ==  name) return i;
    }
    return -1;
}

int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
      if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;

}

int LastPosition(string arrangement[],string name, int current_position) // finds the last occurance of the fish in the arrangement
{
   int last_position = -1;
   for(int i = 0; i < current_position; i++)
   {
       if(arrangement[i] == name) last_position = i;
   }
   return last_position;
}

int FirstPosition(string arrangement[], string name, int current_position)// finds first occurance of the fish in the arrangement
{
    for(int i = 0; i < current_position; i++)
    {
       if(arrangement[i] == name) return i;
    }
   return -1;

}

int Analyzer(string arrangement[], string name, int current_position)
{
    int last = LastPosition(arrangement, name, current_position);
    if(last == -1) return 1; // meaning the last is the current
    if(last/3 == current_position/3) return -1; // signal to do nothing - fish already printed in row
    int first = FirstPosition(arrangement, name, current_position);
    int rowDiff = (current_position/3)- (first/3);
    return 5 * rowDiff + 1;
}

bool Printer(string species, char pattern, int number, int space_number) // prints line of fish
{
    string array1[3];
    string line;
    ifstream Design;
    Design.open("FishDesigns.txt");
    while(getline(Design, line))
    {
        split(line, ',', array1, 3);
        if(array1[0]== species)
        {
            if(stoi(array1[1]) == number)
            {
                string string1 = array1[2];
                int length;
                if(space_number > 9 && array1[1] == "3" && species == "NA") length = string1.length() -1;
                else length = string1.length();
                for(int i = 0; i < length; i++)
                {
                    if(string1[i] == '/') cout << " ";
                    else if(string1[i] == '*')cout << pattern;
                    else if(string1[i] == 'i')cout << space_number;
                    else if(string1[i] == '`')cout <<"/";
                    else cout << string1[i];
                }
                return true;
            }
        }
    }
    return false;

}

string getSpecies(string name, vector <Fish>tankFish)
{
   int position = LookupFish(name, tankFish);
   string species = tankFish[position].getSpecies();
   return species;
}

char getPattern(string name,vector<Fish>tankFish)
{
    int position = LookupFish(name, tankFish);
    char pattern = tankFish[position].getPattern();
    return pattern;
}

int getSize(string name,vector<Fish>tankFish)
{
    int position = LookupFish(name, tankFish);
    int size = tankFish[position].getSize();
    return size;
}

string getOrientation(string name,vector<Fish>tankFish)
{
    int position = LookupFish(name, tankFish);
    string orientation = tankFish[position].getOrientation();
    return orientation;
}

void Print_Tank(string arrangement[], int tank_size, vector <Fish>tankFish)// prints entire tank
{
    cout << " ";
    if(tank_size == 1)for(int n = 0; n < 20; n++)cout << "_";
    else for(int n = 0; n < 60; n++)cout << "_";
    cout << endl;
    for(int i = 0; i < tank_size; i = i + 3)
    {
        for(int k = 0; k < 5; k++){
        cout << "|";
        for(int j = i; j < i + 3 ; j++)
        {
            if(arrangement[j] == "NA") Printer("NA", '*',k+1,j);
            else{
                int analysis = Analyzer(arrangement, arrangement[j], j);
                if(analysis == -1);
                else{
                    string species = getSpecies(arrangement[j],tankFish);
                    char pattern = getPattern(arrangement[j],tankFish);
                    Printer(species, pattern, k+ analysis, j);
                }
            }
            if(tank_size == 1) j = i +3;
        }
        cout << "|" << endl;
        }
    }
    cout << " ";
    if(tank_size == 1)for(int n = 0; n < 20; n++)cout << "_";
    else for(int n = 0; n < 60; n++)cout << "_";
    cout << endl;
}


//small fish = one space 1x1, medium fish= two adjacent spaces 1x2, large fish= three adjacent spaces 1x3
//huge fish = two rows of three adjacent spaces 2x3, gigantic fish = 3x3, epic fish = 9x3

bool checkNumber(string string1)
{
    for(int i = 0; i < string1.length(); i++)
    {
        if(!isdigit(string1[i]))return false;
    }
    return true;
}



void sortArray(int array1[], int size) // sorts user responses
{
   for(int i= 0;  i < size; i++)
   {
      int minimum = array1[i];
      int minimum_position = i;
      for(int j = i+1; j < size; j++)
      {
        if(array1[j] < minimum)
        {
            minimum = array1[j];
            minimum_position = j;
        }
      }
      array1[minimum_position]=array1[i];
      array1[i]= minimum;
   }
}

bool IsAdjacent(int value1, int value2) // must be in order
{
   if(value2 == value1 + 1 && value1 / 3 == value2 / 3) return true;
   return false;
}

bool IsInColumn(int value1, int value2)//must be in order
{
  if(value2 == value1 + 3)  return true;
  return false;
}



bool Tank_checker(int fish_size, string orientation, int tank_size, string arrangement[81], string fish_name,vector <Fish>tankFish)
{
    //cout << arrangement[1] << "x";
    int arr[81];
    int spacenumber = 0; //keeps track of number of digits user entered
    Print_Tank(arrangement, tank_size, tankFish);
    cout << "Where would you like to put the fish?" << endl;
    cout << "Enter the numbers representing the spaces you would like to put the fish" << endl;
    cout << "Fish size: " << fish_size << " ; orientation : " << orientation << endl;
    for(int i = 0; spacenumber < fish_size; i++)
    {
        string value;
        cin >> value;
        if(checkNumber(value))
        {
            if(stoi(value) < tank_size)
            {
                //cout << arrangement[stoi(value)] << arrangement[1] <<"y";
                if (arrangement[stoi(value)] == "NA")
                {
                    arr[i]= stoi(value);
                    spacenumber++;
                    arrangement[stoi(value)] = fish_name;
                    //cout << arrangement[i];
                }
                else cout << "Entries must be unoccupied spaces" <<endl;
            }
            else cout << "Entries must be spaces within the tank" <<endl;
        }
        else cout << "Entries must be numbers." << endl;
    }
    sortArray(arr, fish_size);
    if(orientation == "normal"){
    if (fish_size == 2){
        if(IsAdjacent(arr[0], arr[1]))return true;
        return false;
    }
    for(int i = 0; i < fish_size- 1; i = i+ 3)
    {
        if(!IsAdjacent(arr[i], arr[i+1])|| !IsAdjacent(arr[i+1], arr[i+2])) return false;
    }
    for(int j = 0; j <= fish_size-6; j++)
    {
       //cout << "g" << arr[j] << arr[j+3] << endl;
       if(!IsInColumn(arr[j], arr[j+3]))return false;
    }
     return true;}
    if(orientation == "sideways"){
        //cout << "m";
        if(fish_size == 2){
            if(IsInColumn(arr[0], arr[1])) return true;
            return false;}
        if(fish_size == 3){
            if(IsInColumn(arr[0], arr[1])&& IsInColumn(arr[1], arr[2])) return true;
            return false;
        }
       if(fish_size == 6){
           if(!IsInColumn(arr[0], arr[2])|| !IsInColumn(arr[2],arr[4]))return false;
           if(!IsInColumn(arr[1], arr[3])|| !IsInColumn(arr[3],arr[5]))return false;
           if(!IsAdjacent(arr[0], arr[1]))return false;
           return true;
       }

    }


}

bool fish_placer(int fish_size, string orientation, int tank_size, string arrangement[], string fish_name, vector <Fish>tankFish)// fish goes in tank
{
    if(fish_size > tank_size)
    {
        cout << "This fish is too big to fit in this tank." << endl;
        return false;
    }
    int space_remaing = tank_size;
    for(int i = 0; i < tank_size; i++) {
       if(arrangement[i] != "NA") space_remaing = space_remaing - 1;
    }
    if(fish_size > space_remaing)
    {
        cout << "There is not room for a fish this size in this tank" << endl;
        return false;
    }
    string ray[81];
    string user_response;
    bool placed_fish = false;
    while(placed_fish == false)
    {
        for(int i= 0; i < tank_size; i++)
        {
            ray [i] = arrangement[i];
        }
        placed_fish = Tank_checker(fish_size, orientation, tank_size, ray, fish_name, tankFish);
        if(placed_fish == false)
        {
            cout << "The fish must be placed in one continuous space" << endl;
            cout << "Continue placing fish?(Yes/No)" << endl;
            cin >> user_response;
            if(user_response == "No" || user_response == "no" || user_response == "n" || user_response == "N") return false;
        }
    }
    for(int i= 0; i < tank_size; i++)
        {
            arrangement[i] = ray[i];
        }
    return true;
}



Tank :: Tank(int Size, string name)
{
    size = Size;
    cleanliness = 0;
    water_quality = 0;
    tankName = name;
    for(int i = 0; i < size; i++)
    {
        arrangement[i] = "NA";
    }
}

void Tank :: setCleanliness(int newclean)
{
    cleanliness = newclean;
}
int Tank :: getCleanliness()
{
    return cleanliness;
}

int Tank :: getWaterQuality()
{
    return water_quality;
}

void Tank :: setWaterQuality(int newquality)
{
    water_quality = newquality;
}
string Tank :: getTankName()
{
    return tankName;
}

void Tank :: displayTank()
{
    Print_Tank(arrangement, size, tankFish);
}

void Tank :: listTank()
{

    Print_Tank(arrangement, size, tankFish);
    cout << "Tank " << tankName <<", size " << size << endl;
    if(cleanliness == -10) cout << "The tank is absolutely filthy." << endl;
    if(cleanliness == -9 || cleanliness == -8) cout << "The tank is extremely dirty." << endl;
    if(cleanliness <= -3 && cleanliness >= -7) cout << "The tank is dirty." << endl;
    if(cleanliness > -3 && cleanliness < 3) cout<< "The tank is neither clean nor dirty." << endl;
    if(cleanliness >= 3 && cleanliness <= 7) cout << "The tank is clean." << endl;
    if(cleanliness == 9 || cleanliness == 8) cout << "The tank is extremely clean." << endl;
    if(cleanliness == 10) cout << "The tank is spotless." << endl;
    if(water_quality == -10) cout << "The water is toxic." << endl;
    if(water_quality == -9 || water_quality == -8) cout << "The water pH is extremely unbalanced." << endl;
    if(water_quality <= -3 && water_quality >= -7) cout << "The water pH is unbalanced." << endl;
    if(water_quality > -3 && water_quality < 3) cout<< "The water quality is neutral." << endl;
    if(water_quality >= 3 && water_quality <= 7) cout << "The water pH is balanced." << endl;
    if(water_quality == 9 || water_quality == 8) cout << "The water pH is very well balanced." << endl;
    if(water_quality == 10) cout << "The water pH is perfect." << endl;

}
void Tank :: listFish()
{
    if(tankFish.size() == 0) cout << "There are no fish in this tank" << endl;
    //cout<< tankFish.size();
    else for(int i = 0; i < tankFish.size(); i++ )
    {
        if(i == 0)cout << "Here is a list of fish:" <<endl;
        cout << i+ 1 << ". "<< tankFish[i].getName() <<", " << tankFish[i].getSpecies() << ", Health: "<< tankFish[i].getHealth() << ", Happiness: " << tankFish[i].getHappiness() <<endl;
    }
}

bool Tank :: addFish(Fish newfish)
{
    int fishSize = newfish.getSize();
    string orientation = newfish.getOrientation();
    string fishname = newfish.getName();
    if(fish_placer(fishSize, orientation, size, arrangement, fishname, tankFish))
    {
        tankFish.push_back(newfish);
        Print_Tank(arrangement, size, tankFish);
        cout << "The fish has been successfully added." << endl;
        return true;
    }
    cout << "Fish placement canceled" <<endl;
    return false;
}

bool Tank :: removeFish(int fishnumber)
{
    string fishname = tankFish[fishnumber-1].getName();
    tankFish.erase(tankFish.begin() + (fishnumber-1));
    for(int i = 0; i < size; i++)
    {
        if(arrangement[i] == fishname) arrangement[i] = "NA";
    }
    cout << fishname <<" was successfully removed from tank " << tankName <<endl;
    return true;
}

bool Tank :: moveFish()
{
   Print_Tank(arrangement, size, tankFish);
   if(tankFish.size() == 0)
   {
       cout << "There are no fish in this tank" << endl;
       return false;
   }
    else for(int i = 0; i < tankFish.size(); i++ )
    {
        if(i == 0)cout << "Which fish would you like to move?" <<endl;
        cout << i+ 1 << ". "<< tankFish[i].getName() <<", " << tankFish[i].getSpecies() << ", Health: "<< tankFish[i].getHealth() << ", Happiness: " << tankFish[i].getHappiness() <<endl;
    }
    int fishnumber;
    if(! (cin >> fishnumber))
    {
        cout << "invalid input, move canceled" << endl;
        return false;
    }
    if(fishnumber > tankFish.size() || fishnumber < 0)
    {
        cout << "invalid input, move canceled" << endl;
        return false;
    }
    string temp[200];
    string fishname = tankFish[fishnumber-1].getName();
    int fishSize = tankFish[fishnumber-1].getSize();
    string orientation = tankFish[fishnumber-1].getOrientation();
    for(int i = 0; i < size; i++)
    {
        if(arrangement[i] == fishname) temp[i] = "NA";
        else temp[i] = arrangement[i];
    }
    if(fish_placer(fishSize, orientation, size, temp, fishname, tankFish))
    {
        for(int i = 0; i < size; i++) arrangement[i] = temp[i];
        Print_Tank(arrangement, size, tankFish);
        cout << "Fish successfully moved" << endl;
        return true;
    }
    Print_Tank(arrangement, size, tankFish);
    cout << "Fish move canceled" <<endl;
    return false;

}

void Tank :: resetTank() // reset happens at the end of each day
{
    for(int i =0; i < tankFish.size(); i++)
    {
        bool isfed;
        if(tankFish[i].getFed() < tankFish[i].getFoodNumber()) {
            tankFish[i].changeHealth(-1);
            tankFish[i].changeHappiness(-2);
            isfed = false;
        }
         else isfed= true;

        if(cleanliness == -10) tankFish[i].changeHappiness(-3);
        if(cleanliness == -9 || cleanliness == -8) tankFish[i].changeHappiness(-2);
        if(cleanliness <= -3 && cleanliness >= -7) tankFish[i].changeHappiness(-1);
        if(cleanliness > -3 && cleanliness < 3);
        if((cleanliness >= 3 && cleanliness <= 7) && isfed) tankFish[i].changeHappiness(1);
        if((cleanliness == 9 || cleanliness == 8)&& isfed) tankFish[i].changeHappiness(2);
        if((cleanliness == 10)&& isfed) tankFish[i].changeHappiness(3);
        if(water_quality == -10) tankFish[i].changeHealth(-3);
        if(water_quality == -9 || water_quality == -8) tankFish[i].changeHealth(-2);
        if(water_quality <= -3 && water_quality >= -7) tankFish[i].changeHealth(-1);
        if(water_quality > -3 && water_quality < 3);
        if((water_quality >= 3 && water_quality <= 7)&& isfed) tankFish[i].changeHealth(1);
        if((water_quality == 9 || water_quality == 8)&& isfed) tankFish[i].changeHealth(2);
        if((water_quality == 10)&& isfed) tankFish[i].changeHealth(3);

        tankFish[i].resetFed();
        if(tankFish[i].getHappiness() <= -10) tankFish[i].changeHealth(-1);
        if(tankFish[i].getHealth() <= -10){
          string fishname = tankFish[i].getName();
          tankFish.erase(tankFish.begin() + i);
          for(int i = 0; i < size; i++)
          {
            if(arrangement[i] == fishname) arrangement[i] = "NA";
          }
          cout << "Your fish " << fishname <<" has died during the night due to poor health. :( You must feed your fish and keep them in a healthy tank to ensure  their survival." <<endl;
        }
    }
    cleanliness = cleanliness - tankFish.size();
    if(cleanliness < -10) cleanliness = -10;
    water_quality = water_quality - tankFish.size();
    if(water_quality < -10) water_quality = -10;
}

bool Tank :: feedFish(Item Item1)
{
    displayTank();
    listFish();
    if(tankFish.size() == 0){
        cout << "There are no fish in this tank to feed" << endl;
        return false;
    }
    cout << "Which fish would you like to feed?" << endl;
    string user_response;
    cin >> user_response;
    if(!checkNumber(user_response)){ cout << "Invalid input" <<endl;
    return false; }
    else if(stoi(user_response) > tankFish.size() || stoi(user_response) == 0){ cout << "Invalid input" <<endl;
    return false;}
    else{
        if(tankFish[stoi(user_response)-1].matchFoodType(Item1.getType()))
        {
            if(tankFish[stoi(user_response)-1].getFed() >= tankFish[stoi(user_response)-1].getFoodNumber()){
                cout << "This fish is full" << endl;
                return false;
            }
            else{
                cout << "You fed " << tankFish[stoi(user_response)-1].getName() << " " << Item1.getName() << endl;
                tankFish[stoi(user_response)-1].changeFed(Item1.getFoodNumber());
                return true;
            }
        }
        else{
            cout << "This fish does not eat " << Item1.getType() <<endl;
            tankFish[stoi(user_response)-1].printFoodType();
            return false;
        }
    }
}

bool Tank :: hasSameName(string testname)
{
    bool sameName = false;
    for(int i = 0; i < tankFish.size(); i++)
    {
       if(tankFish[i].getName() == testname) sameName = true;
    }
    return sameName;
}

string Tank :: getArrangementAt(int number)
{
    return arrangement[number];
}

void Tank :: setArrangementAt(int number, string setting)
{
    arrangement[number] = setting;
}

void Tank :: loadFish(Fish Fish1)
{
    tankFish.push_back(Fish1);
}

int Tank :: getTankSize()
{
    return size;
}

int Tank :: getNumFish()
{
    return tankFish.size();
}

string Tank :: getFishName(int fishnumber)
{
    return tankFish[fishnumber].getName();
}
string Tank :: getFishSpecies(int fishnumber)
{
    return tankFish[fishnumber].getSpecies();
}
char Tank :: getFishPattern(int fishnumber)
{
    return tankFish[fishnumber].getPattern();
}
int Tank :: getFishHappiness(int fishnumber)
{
    return tankFish[fishnumber].getHappiness();
}
int Tank :: getFishHealth(int fishnumber)
{
    return tankFish[fishnumber].getHealth();
}
int Tank :: getFishFed(int fishnumber)
{
    return tankFish[fishnumber].getFed();
}

Fish Tank :: getFish(int fishnumber)
{
    return tankFish[fishnumber];
}