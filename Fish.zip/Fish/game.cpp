#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <time.h> 
#include "game.h"
#include <cmath>
using namespace std;

bool arediff(char char1, string string1)
{
    for(int i = 0;i < string1.length(); i++)
    {
        if(string1[i] == char1) return false;
    }
    return true;
}

int hamming_distance(string sequence1, string sequence2)
{
    int length = sequence1.length();
    int i = 0, hamming_distance = 0; // number of differences b/w two strings
    for (i; i < length && i < sequence2.length(); i++)
    {
        if(sequence1[i] != sequence2[i])hamming_distance++; // compares each character in one string to the other in the same position
    }
    return hamming_distance;
}


void Instructions()
{
    cout << "Instructions:" << endl;
    cout << "The goal of this game is to guess a sequence of 10 randomly arranged numbers" <<endl;
    cout << "Each number from 0 to 9 appears once in the sequence" <<endl;
    cout << "Enter a string of 10 digits" <<endl;
    cout << "If your guess does not match the sequence you will receive the number of digits which were in the incorrect place as feedback" <<endl;
    cout << "You will then be able to make another guess" <<endl;
    cout << "To quite type Quit or q" <<endl;
    cout << "Try to get the sequence in as few guesses as possible." <<endl <<endl;
}


string generateSequence()
{
    srand (time(NULL));
    int random;
    char digits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    string string1 = ""; 
    while(string1.length() < 10)
    {
        random = rand() % 10;
        if(arediff(digits[random], string1)) string1 = string1 + digits[random];
    }
    return string1;
}

int game :: numbergame()
{
    Instructions();
    string hiddenSequence = generateSequence();
    string guess;
    int numguess = 0;
    cout << "Type in your guess" <<endl;
    while(guess != "Quit" && guess != "quit" && guess != "q" && guess != "Q")
    {
        cin >> guess;
        numguess ++;
        if( guess == hiddenSequence)
        {
            cout << "Congratulations! You guessed the code!" <<endl;
            cout << "Score: " << numguess << " guesses"<<endl;
            return numguess;
        }
        else{
            int value = hamming_distance(guess, hiddenSequence);
            cout << guess << "      " << value << " differences" << endl;
        }
        
    }
    return 100;
}

int rollDice()
{
	srand (time(NULL));
	return random() % 6 + 1; 
}

// your 3 + functions go in here
void print_text(string player, int diceRoll, int turntotal)
{
  if (diceRoll == -4) diceRoll =1;// converts turn vales back into dice rolls
  if (diceRoll == -1) diceRoll =6;
  if (diceRoll == -2) diceRoll =3;
  if(player == "human" && diceRoll > 0)// make sure it's above zero so this is skipped when turn value is -3
  {
     cout << "You rolled a "<< diceRoll<< endl << "Your turn total is "<< turntotal <<endl;  
  }
  if(player == "computer" && diceRoll > 0)
  {
     cout << "Computer rolled a " << diceRoll << endl <<"Computer turn total is "<<turntotal <<endl;
  }
}

int round(string player, int turntotal)
{
   if(player == "human")
   {
      if(turntotal == 0)//if it's zero they haven't gone yet
       {
           cout << "Do you want to roll a dice (Y/N)?:" << endl;
       }
       else
       {
           cout << "Do you want to roll again (Y/N)?:" << endl;
       }
       string user_response;
       cin >> user_response;
       if(user_response[0] == 'N' || user_response[0] =='n') return -3;//neg numbers will tell the turn loop to end
   }
   if (player == "computer" && turntotal >= 10) return -3;
   int Diceroll = rollDice();
   int return_value;
   switch (Diceroll)
   {
       case 2: return_value = 2; break;
       case 4: return_value = 4; break;
       case 5: return_value = 5; break;// the positive numbers will simply add to the turn total
       case 1: return_value = -4; break;
       case 6: return_value = -1; break;
       case 3: return_value = -2; break;// negative numbers will exit the turn
   }
   return return_value;
   
}

int turn(string player)
{
    int roundtotal = 0;
    int turntotal = 0;
    while (roundtotal >= 0) // when it's negative, that indicates a roll or the user ended the turn
    {
        roundtotal = round(player, turntotal);
        turntotal = turntotal + roundtotal;
        if (roundtotal > 0) print_text(player, roundtotal, turntotal);
    }
    if (roundtotal == -1 || roundtotal == -4) turntotal = 0;//convert exit codes into there effect
    if (roundtotal == -2)  turntotal = 15;
    if (roundtotal == -3) turntotal = turntotal + 3;// add the three subtracted in the loop
    print_text(player, roundtotal, turntotal);
    return turntotal;//gives total for this turn back to the game function
}

/**
 * game 
 * driver function to play the game
 * the function does not return any value
 */

void game :: jeapardyDice()
{

cout << "Welcome to Jeopardy Dice!" << endl << endl;
    int human_total = 0;
    int computer_total = 0;
    bool whose_turn = 0; // if value is zero, humans turn, value one computer's turn
    while (human_total < 100 && computer_total < 100) // continues turns until game is won
    {
        if(whose_turn == 0)
        {
            cout << "It is now human's turn" <<endl << endl;
            human_total= human_total + turn("human"); // the turn function will return the total for this turn
            whose_turn = 1;// after human change back to computer's turn
        }
        else
        {
            cout << "It is now computer's turn"<<endl <<endl;
            computer_total= computer_total + turn("computer");
            whose_turn = 0;
        }
        
    cout << "computer: " << computer_total << endl <<"human: "<<human_total << endl <<endl;
    }
    if(computer_total >= 100)
    {
        cout << "Congratulations! computer won this round of jeopardy dice!" <<endl;
    }
    if(human_total >= 100)
    {
        cout << "Congratulations! human won this round of jeopardy dice!" <<endl;

    }
}

// void game :: jeapardyDice()
// {
//     game();
// }

bool Cnumber(string string1)
{
    for(int i = 0; i < string1.length(); i++)
    {
        if(!isdigit(string1[i]))return false;
    }
    return true;
}

int rollDice(int legal)
{
	srand (time(NULL));
	return random() % legal + 1; 
}

int stupid(int marbles)
{
    int legal = marbles/2;
    return rollDice(legal);
}

int smart(int marbles)
{
    int nearest = log(marbles)/log(2);
    int power = pow(2, nearest)- 1;
    int last =pow(2, (nearest+1))-1;
    if(marbles == last) return stupid(marbles);
    else return(marbles - power);
}

int Human_move(int marbles)
{
    string user_response = "0";
    int legal = marbles/2;
    while(stoi(user_response) > legal || stoi(user_response) < 1)
    {
    cout <<"Your move. Marbles remaining: " << marbles<< endl;
    cin >> user_response;
    if(Cnumber(user_response)){
    if (stoi(user_response) > legal || stoi(user_response) < 1)
        {
        cout << "Wrong Move. You can only choose between 1 to " << legal <<endl;
        user_response = "0";

        }
    }
    else{
        cout << "You must enter a number" <<endl;
        user_response = "0";
    } 
    }
     return marbles - stoi(user_response);
    
}

int Computer_move(int marbles, bool compmode)
{
    cout << "Computer is playing.." << endl;
    int taken;
    if(compmode == 0) taken = stupid(marbles);
    else taken = smart(marbles);
    cout << "Computer took "<<taken<<endl;
    return marbles - taken;
}

void game :: marbleRun(int marbles, bool compmode, bool turn)
{
    string first_player;
    if(turn == 1) first_player = " Computer";
    else first_player = " Human";
    cout<< "Lets start the game!" << endl; 
    cout<< "Initial size is: "<< marbles <<endl<< "First player to play:" << first_player<<endl;
    string answer;
    if (compmode == 0) answer = " No";
    else answer = " Yes";
    cout << "Is computer in smart mode?"<<answer<<endl;
    while(marbles > 1)
    {
        if(turn == 1)
        {
            marbles = Computer_move(marbles, compmode);
            turn = 0;
        }
        else
        {
            marbles = Human_move(marbles);
            turn = 1;
        }
        cout << "Remaining marbles: "<< marbles<< endl;;
    }
    if(turn == 1) cout <<"You Win. Computer loses"<<endl;
    else cout << "You lose. Computer won" <<endl;
    
}

// int main()
// {
//     jeapardyDice();
// }
