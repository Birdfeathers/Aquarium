// record ones already done & position they're in
// if both old position & new position/3 are same ignore them
// if old position/3 + 1 == newposition- do 6-10, don't replace, then do 11-15 etc.

#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;
    
}

int LastPosition(string arrangement[],string name, int current_position)
{
   int last_position = -1;
   for(int i = 0; i < current_position; i++)
   {
       if(arrangement[i] == name) last_position = i;
   }
   return last_position;
}

int FirstPosition(string arrangement[], string name, int current_position)
{
    for(int i = 0; i < current_position; i++)
    {
       if(arrangement[i] == name) return i;
    }
   return -1;
    
}

int Analyzer(string arrangement[], string name, int current_position)
{
    int last = LastPosition(arrangement, name, current_position);
    if(last == -1) return 1;
    if(last/3 == current_position/3) return -1; // signal to do nothing
    int first = FirstPosition(arrangement, name, current_position);
    int rowDiff = (current_position/3)- (first/3);
    return 5 * rowDiff + 1;  
}

bool Printer(string species, char pattern, int number, int space_number)
{
    string array1[3];
    string line;
    ifstream Design;
    Design.open("FishDesigns.txt");
    while(getline(Design, line))
    {
        split(line, ',', array1, 3);
        if(array1[0]== species)
        {
            if(stoi(array1[1]) == number)
            {
                string string1 = array1[2];
                for(int i = 0; i < string1.length(); i++)
                {
                    if(string1[i] == '/') cout << " ";
                    else if(string1[i] == '*')cout << pattern;
                    else if(string1[i] == 'i')cout << space_number;
                    else cout << string1[i];
                }
                return true;
            }
        }
    }
    return false;
    
}

string getSpecies(string name)//temporary function
{
    string species;
    if(name == "Horsey")species = "Seahorse";
    else if(name == "Munchy")species = "MediumPacificKelpMuncher";
    else if(name == "Packy")species = "Pacu";
    else species = "goldfish";
    return species;
}

char getPattern(string name)//temporary function
{
    char pattern;
    if(name == "Horsey")pattern = 'S';
    else if(name == "Munchy")pattern = 'o';
    else if(name == "Packy")pattern = 'p';
    else pattern = 'g';
    return pattern;
}

void Print_Tank(string arrangement[], int tank_size)
{
    cout << " ";
    if(tank_size == 1)for(int n = 0; n < 20; n++)cout << "_";
    else for(int n = 0; n < 60; n++)cout << "_";
    cout << endl;
    for(int i = 0; i < tank_size; i = i + 3)
    {
        for(int k = 0; k < 5; k++){
        cout << "|";
        for(int j = i; j < i + 3 ; j++)
        {
            if(arrangement[j] == "NA") Printer("NA", '*',k+1,j);
            else{
                int analysis = Analyzer(arrangement, arrangement[j], j);
                if(analysis == -1);
                else{
                    string species = getSpecies(arrangement[j]);
                    char pattern = getPattern(arrangement[j]);
                    Printer(species, pattern, k+ analysis, j);
                }
            }
            if(tank_size == 1) j = i +3;
        }
        cout << "|" << endl;
        }
    }
    cout << " ";
    if(tank_size == 1)for(int n = 0; n < 20; n++)cout << "_";
    else for(int n = 0; n < 60; n++)cout << "_";
    cout << endl;
}



int main()
{
    // string arrangement[9];
    // for(int i = 0; i < 9; i++)
    // {
    //     arrangement[i] = "NA";
    // }
    // arrangement[0] = "fishy";
    // arrangement[3] = "fishy";
    // arrangement[6] = "fishy";
    // arrangement[1] = "hello";
    // arrangement[2] = "hello";
    // cout << Analyzer(arrangement, "fishy", 6)<< endl;
    // cout << Analyzer(arrangement, "fishy", 3)<< endl;
    // cout << Analyzer(arrangement, "fishy", 0)<< endl;
    // cout << Analyzer(arrangement, "hello", 1)<< endl;
    // cout << Analyzer(arrangement, "hello", 2)<< endl;
    // Printer( "goldfish", 'g', 1, 1);
    // cout << endl;
    // Printer( "goldfish", 'g', 2, 1);
    // cout << endl;
    // Printer( "goldfish", 'g', 3, 1);
    // cout << endl;
    // Printer( "goldfish", 'g', 4, 1);
    // cout << endl;
    // Printer( "goldfish", 'g', 5, 1);
    // cout << endl;
    
    
    // Printer( "NA", 'g', 1, 1);
    // cout << endl;
    // Printer( "NA", 'g', 2, 1);
    // cout << endl;
    // Printer( "NA", 'g', 3, 1);
    // cout << endl;
    // Printer( "NA", 'g', 4, 1);
    // cout << endl;
    // Printer( "NA", 'g', 5, 1);
    // cout << endl;
    
    // Printer( "MediumPacificKelpMuncher", 'o', 1, 1);
    // cout << endl;
    // Printer( "MediumPacificKelpMuncher", 'o', 2, 1);
    // cout << endl;
    // Printer( "MediumPacificKelpMuncher", 'o', 3, 1);
    // cout << endl;
    // Printer( "MediumPacificKelpMuncher", 'o', 4, 1);
    // cout << endl;
    // Printer( "MediumPacificKelpMuncher", 'o', 5, 1);
    // cout << endl;
    // Printer( "Pacu", 'o', 5, 1);
    // cout << endl;
    string arrangement[18] = {"fishy", "NA","Horsey", "NA", "fisheye", "Horsey","Munchy", "Munchy","Horsey", "Packy","Packy","Packy","Packy","Packy","Packy","Packy","Packy","Packy"};
    Print_Tank(arrangement,18);
    string arrangement2[1] = { "NA"};
    Print_Tank(arrangement2, 1);
    
}