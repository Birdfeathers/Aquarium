#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include "Item.h"
using namespace std;
#include "Market.h"

bool Checker(string string1)
{
    for(int i = 0; i < string1.length(); i++)
    {
        if(!isdigit(string1[i]))return false;
    }
    return true;
}

void MarketMenu(){
    cout <<"What would you like to buy at the Market?" <<endl;
    cout << "1. Chicken, 20g" <<endl;
    cout << "2. Steak, 50g" <<endl;
    cout << "3. Bread, 10g" <<endl;
    cout << "4. Lettuce, 5g" <<endl;
    cout << "5. Apple, 10g" <<endl;
    cout << "6. Walnut, 60g" <<endl;
    cout << "7. Pizza, 20g" <<endl;
    cout << "8. Spaghetti, 10g" <<endl;
    cout << "9. FishingPole, 150g" <<endl;
    cout << "10. nevermind" <<endl;
}

void statement(int money, string itemname)
{
    cout << "You do not have enough money to buy "<< itemname << endl;
    cout << "Money: " << money << "g" <<endl;
}

int Market :: buyitem(int money)
{
    MarketMenu();
    string user_response;
    cin >> user_response;
    if(Checker(user_response)){
    switch(stoi(user_response)){
       case 1: 
        if(money < 20)
        {
           statement(money, "Chicken");
           return -1;
        }
       else return stoi(user_response);
       case 2:
        if(money < 50)
        {
           statement(money, "Steak");
           return -1;
        }
        else return stoi(user_response);
       case 3:
        if(money < 10)
        {
           statement(money, "Bread");
           return -1;
        }
        else return stoi(user_response);
       case 4:
        if(money < 5)
        {
           statement(money, "Lettuce");
           return -1;
        }
        else return stoi(user_response);
       case 5:
        if(money < 10)
        {
           statement(money, "Apple");
           return -1;
        }
        else return stoi(user_response);
       case 6:
        if(money < 60)
        {
           statement(money, "Walnut");
           return -1;
        }
        else return stoi(user_response);
       case 7:
        if(money < 20)
        {
           statement(money, "Pizza");
           return -1;
        }
        else return stoi(user_response);
       case 8:
        if(money < 10)
        {
           statement(money, "Spaghetti");
           return -1;
        }
        else return stoi(user_response);
       case 9:
       if(money < 150)
        {
           statement(money, "FishingPole");
           return -1;
        }
        else return stoi(user_response);
       case 10:
        cout << "too bad" <<endl;
        return -1;
       default:
        cout << "invalid input" <<endl;
        return -1;
    }
       
    }
    else cout<< "Invalid input" <<endl;
    return -1;
}

int Market :: marketprice(int number)
{
    switch(number){
        case 1:
            return 20;
        case 2:
            return 50;
        case 3:
            return 10;
        case 4:
            return 5;
        case 5:
            return 10;
        case 6:
            return 60;
        case 7:
            return 20;
        case 8:
            return 10;
        case 9:
            return 150;
    }
}

Item Market :: marketitem(int number)
{
    Item chicken("chicken");
    Item steak("steak");
    Item bread("bread");
    Item lettuce("lettuce");
    Item apple("apple");
    Item walnut("walnut");
    Item pizza("pizza");
    Item spaghetti("spaghetti");
    Item fishingPole("fishingPole");
    switch(number)
    {
        case 1:
            cout << "You bought chicken" <<endl;
            return chicken;
        case 2:
            cout << "You bought steak" <<endl;
            return steak;
        case 3:
            cout << "You boutght bread" <<endl;
            return bread;
        case 4:
            cout << "You bought lettuce" <<endl;
            return lettuce;
        case 5:
            cout << "You bought apple" <<endl;
            return apple;
        case 6:
            cout << "You bought walnut" <<endl;
            return walnut;
        case 7:
            cout << "You bought pizza" <<endl;
            return pizza;
        case 8:
            cout << "You bought spaghetti" <<endl;
            return spaghetti;
        case 9:
            cout << "You bought fishingPole" <<endl;
            return fishingPole;
    }
}

int Market :: sellItem(string itemname)
{
    
    if(itemname == "smallFish") return 10;
    if(itemname == "mediumFish") return 50;
    if(itemname == "largeFish") return 100;
    if(itemname == "redFish") return 200;
    if(itemname == "mussels") return 50;
    if(itemname == "crawfish") return 10;
    if(itemname == "chicken")return 5;
    if(itemname == "steak")return 13;
    if(itemname == "bread") return 3;
    if(itemname == "lettuce") return 2;
    if(itemname == "apple") return 3;
    if(itemname == "veryBerry") return 10;
    if(itemname == "walnut") return 15;
    if(itemname == "acorn") return 50;
    if(itemname == "pizza")return 4;
    if(itemname == "spaghetti") return 3;
    if(itemname == "pearl") return 2000;
    if(itemname == "rock" || itemname == "stick" ) return 5;
    return -1;
}