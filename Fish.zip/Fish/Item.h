#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#ifndef ITEM_H
#define ITEM_H

class Item
{
    public:
        
        Item(string itemname);
        bool getEdible();
        string getName();
        void setNumber(int newNumber);
        int getNumber();
        string getType();
        int getFoodNumber();
    private:
        string itemName;
        bool edible;
        string type;
        int number;
        int foodnumber;
        
        
};

#endif