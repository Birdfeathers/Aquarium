#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#include "User.h"

int main()
{
    User User1;
    cout << User1.getDrowsiness() << endl;
    cout << User1.getMoney() << endl;
    cout << User1.getStamina() << endl;
    User1.setDrowsiness(0);
    User1.setMoney(88);
    User1.setStamina(6);
    cout << User1.getDrowsiness() << endl;
    cout << User1.getMoney() << endl;
    cout << User1.getStamina() << endl;
}