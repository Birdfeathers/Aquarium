#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include "Pond.h"
using namespace std;

void Pond :: PondMenu()
{
	cout << "What would you like to do at the pond?" <<endl;
	cout << "1. Search pond" <<endl;
	cout << "2. Fish" <<endl;
	cout << "3. Leave" <<endl;
}

char Pond :: randomchar()
{
    srand (time(NULL));
	int random = rand() % 100; 
	switch(random){
	    case 0 : return '0';
	    case 1 : return '1';
	    case 2 : return '2';
	    case 3 : return '3';
	    case 4 : return '4';
	    case 5 : return '5';
	    case 6 : return '6';
	    case 7 : return '7';
	    case 8 : return '8';
	    case 9 : return '9';
	    case 10 : return 'a';
	    case 11 : return 'b';
	    case 12 : return 'c';
	    case 13 : return 'd';
	    case 14 : return 'e';
	    case 15 : return 'f';
	    case 16 : return 'g';
	    case 17 : return 'h';
	    case 18 : return 'i';
	    case 19 : return 'j';
	    case 20 : return 'k';
	    case 21 : return 'l';
	    case 22 : return 'm';
	    case 23 : return 'n';
	    case 24 : return 'o';
	    case 25 : return 'p';
	    case 26 : return 'q';
	    case 27 : return 'r';
	    case 28 : return 's';
	    case 29 : return 't';
	    case 30 : return 'u';
	    case 31 : return 'v';
	    case 32 : return 'w';
	    case 33 : return 'x';
	    case 34 : return 'y';
	    case 35 : return 'z';
	    case 36 : return 'A';
	    case 37 : return 'B';
	    case 38 : return 'C';
	    case 39 : return 'D';
	    case 40 : return 'E';
	    case 41 : return 'F';
	    case 42 : return 'G';
	    case 43 : return 'H';
	    case 44 : return 'I';
	    case 45 : return 'J';
	    case 46 : return 'K';
	    case 47 : return 'L';
	    case 48 : return 'M';
	    case 49 : return 'N';
	    case 50 : return 'O';
	    case 51 : return 'P';
	    case 52 : return 'Q';
	    case 53 : return 'R';
	    case 54 : return 'S';
	    case 55 : return 'T';
	    case 56 : return 'U';
	    case 57 : return 'V';
	    case 58 : return 'W';
	    case 59 : return 'X';
	    case 60 : return 'Y';
	    case 61 : return 'Z';
	    case 62 : 
	    case 63 : return '{';
	    case 64 : return '}';
	    case 65 : return '(';
	    case 66 : return ')';
	    case 67 : return '[';
	    case 68 : return ']';
	    case 69 : return '!';
	    case 70 : return '@';
	    case 71 : return '#';
	    case 72 : return '$';
	    case 73 : return '%';
	    case 74 : return '^';
	    case 75 : return '&';
	    case 76 : return '*';
	    case 77 : return '<';
	    case 78 : return '>';
	    case 79 : return '.';
	    case 80 :
	    case 81 : return '?';
	    case 82 : return '/';
	    case 83 : return '\'';
	    case 84 : return '|';
	    case 85 : return ';';
	    case 86 : return ':';
	    case 87 : return '+';
	    case 88 : return '=';
	    case 89 : return '`';
	    case 90 : return '~';
	    case 91 : return '-';
	    case 92 : return '\'';
	    case 93 : return '\"';
	    case 94 : return '{';
	    case 95 : return '}';
	    case 96 : return '[';
	    case 97 : return ']';
	    case 98 : return '>';
	    case 99 : return '<';
	}
}

string Pond :: returnSpecies()
{
    srand(time(NULL));
    int random = rand() % 100; 
    if(random == 0)return "LakeMonster";
    if(random < 75)return "goldfish";
    if(random < 95) return "Pacu";
    return "BoxTurtle";
    
}

string Pond :: fish()
{
    srand (time(NULL));
	int random = rand() % 100;
	if(random < 25) return "nothing";
	if(random < 45) return "fish";
	return "item";
}

string Pond :: scavenged()
{
	srand (time(NULL));
	int random = rand() % 100;
	if(random < 25) return "trash";
	if(random < 50) return "stick";
	if(random < 75) return "catTailRoot";
	return "worm";
}

string Pond :: item()
{
	srand (time(NULL));
	int random = rand() % 100;
	if(random <15) return "smallFish";
	if(random <25) return "mediumFish";
	if(random <30) return "largeFish";
	if(random < 55) return "mosquitoLarvae";
	if(random < 65) return "crawfish";
	if(random < 75) return "algae";
	if(random < 85) return "stick";
	return "trash";
}