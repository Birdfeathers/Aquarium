#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Beach.h"
#include "Fish.h"
#include "Item.h"
#include "Market.h"
#include "PetStore.h"
#include "Pond.h"
#include "Tank.h"
#include "User.h"
#include "Day.h"
#include "Forest.h"
//#include "game.h"
using namespace std;

int sPliT(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;
    
}

bool Checknumber(string string1)
{
    for(int i = 0; i < string1.length(); i++)
    {
        if(!isdigit(string1[i]))return false;
    }
    return true;
}

bool Day :: listTanks()
{
    if(mytanks.size() == 0){ 
        cout <<"You have no tanks." <<endl;
        return false;
    }
    for(int i = 0; i < mytanks.size() ; i++)
    {
        cout << i + 1 << ". " << mytanks[i].getTankName() << endl;
    }
    return true;
}

bool Day :: placingfish(string species, char pattern)
{
    bool end = false;
    bool samename = false;
    string user_response;
    while(end == false){
    cout << "What would you like to name this fish?" << endl;
    cin >> user_response;
    for(int i = 0; i < mytanks.size(); i++)
    {
        if(mytanks[i].hasSameName(user_response)) samename = true;
    }
    if(samename){
        cout <<"You already have a fish with this name. Each fish must have a unique name." << endl;
        samename = false;
    }
    else end = true;
    }
    Fish Fish1(user_response, species, pattern);
    listTanks();
    end = false;
    string tanknum;
    while(end == false){
    cout << "Which tank would you like to put " << user_response << " in?" << endl;
    cin >> tanknum;
    if(!Checknumber(tanknum)) cout << "Invalid input" << endl;
    else{
            if(stoi(tanknum) == 0 || stoi(tanknum) > mytanks.size()) cout << "Invalid input" << endl;
            else{
                    if(mytanks[stoi(tanknum) -1].addFish(Fish1)) return true;
                    else cout << "placement canceled" <<endl;
                    return false;
                    end = true;
                }
    }
}
}


void whatFishMenu()
{
    cout << "What would you like to do?" <<endl;
    cout << "1. Let it go" << endl;
    cout << "2. Place in tanks" <<endl;
}

void displayitems(vector <Item>& inventory)
{
    for(int i = 0; i < inventory.size(); i++)
        {
            cout << i + 1 << ". " << inventory[i].getName() << " x" << inventory[i].getNumber() << endl;
        }
}

bool removeitem(vector <Item>&items, int itemnumber, int number)
{
    
    if(items[itemnumber].getNumber() <= number ) items.erase(items.begin() + itemnumber);
    else items[itemnumber].setNumber(items[itemnumber].getNumber() - number);
    
}

bool Day :: hasFishingPole()
{
    for(int i = 0; i < inventory.size(); i++)
    {
        if(inventory[i].getName() == "fishingPole") return true;
    }
    return false;
}

Day :: Day()
{
   hour = 6;
   daynumber = 0;
   guessHigh = 100;
   score = 0;
}
void Day :: advanceHour(int hours)
{
    for(int i = 0; i < hours; i++)
    {
        if(hour == 23)
        {
            hour = -1;
            daynumber++;
            for(int j = 0; j < mytanks.size(); j++)
            {
                mytanks[j].resetTank();
            }
        }
        hour++;
        one.setDrowsiness(one.getDrowsiness() + 1);
    }
}

int Day :: getDay()
{
    return daynumber;
}

int Day :: getHour()
{
    return hour;
}

int Day :: getMoney()
{
    return one.getMoney();
}

int Day :: getDrowsiness()
{
  return one.getDrowsiness();  
}
        
int Day :: getStamina()
{
    return one.getStamina();
}

void Day :: setDrowsiness(int newDrowsiness)
{
    one.setDrowsiness(newDrowsiness);
}
       
void Day :: setStamina(int newStamina)
{
    one.setStamina(newStamina);
}

int Day :: checkInventory()
{
    int return_number = 0;
    if(inventory.size() == 0)cout << "You have no items in your inventory" << endl;
    else{
        displayitems(inventory);
        string user_response;
        cout << "Would you like to examine any of your items?(Yes/No)" <<endl;
        cin >> user_response;
        if(user_response== "No" || user_response == "no" || user_response == "n" || user_response == "N");
        else{
            while(user_response != "end")
            {
                displayitems(inventory);
                cout << "Enter the number of the item you would like to examine." << endl;
                cin >> user_response;
                if(!Checknumber(user_response))cout << "Invalid input." <<endl;
                else if(stoi(user_response) > inventory.size())cout << "Invalid input" << endl;
                else{
                    int itemnumber = stoi(user_response) - 1;
                    cout << "What would you like to do with the " << inventory[stoi(user_response) - 1].getName() <<endl;
                    cout << "1. eat it." <<endl;
                    cout << "2. throw it away." <<endl;
                    cout << "3. nevermind" <<endl;
                    cin >> user_response;
                    if(!Checknumber(user_response)) cout << "Invalid input." << endl;
                    else if(stoi(user_response) == 1) 
                    {
                        if(inventory[itemnumber].getEdible()){
                            cout << "How many would you like to eat?" <<endl;
                            cin >> user_response;
                            if(!Checknumber(user_response)) cout << "Invalid input." << endl;
                            else if(stoi(user_response) > inventory[itemnumber].getNumber()) cout << "You cannot eat more than you have" <<endl;
                            else{
                                return_number = return_number + (stoi(user_response) * inventory[itemnumber].getFoodNumber());
                                removeitem(inventory, itemnumber, stoi(user_response));
                            }
                        }
                        else cout << "You can only eat edible items." <<endl;
                    }
                    else if(stoi(user_response) == 2)
                    {
                       cout << "How many would you like to throw away?" <<endl;
                       cin >> user_response;
                       if(!Checknumber(user_response)) cout << "Invalid input." << endl;
                       else{
                           removeitem(inventory, itemnumber, stoi(user_response));
                           cout << "Items have been removed from your inventory" << endl;
                       }
                    }
                if(inventory.size() <= 0){
                        cout << "You have no more items" << endl;
                        user_response == "end";
                        return return_number;
                    }
                }
                cout << "Would you like to examine another item (Yes/No)"<< endl;
                cin >> user_response;
                if(user_response== "No" || user_response == "no" || user_response == "n" || user_response == "N") user_response = "end";
            }
        }
        
    }
    return return_number;
}

bool Day ::addItem(Item Item1)
{
    for(int i = 0; i < inventory.size() ; i++)
    {
        if(inventory[i].getName() == Item1.getName()){
        inventory[i].setNumber(inventory[i].getNumber()+1);
        return true;
        }
    }
        inventory.push_back(Item1);
        return false;
}

bool Day :: removeItem(int itemnumber)
{
    removeitem(inventory,itemnumber, 1);
    return true;

}


void Day :: examineTank(int tankNumber)
{
    // cout << mytanks.size() << endl;
    // cout << tankNumber << endl;
    if(tankNumber < 0 || tankNumber >= mytanks.size())cout << "This is an invalid number." << endl;
    else{
        bool end = false;
        string user_response;
        while(end == false){
            mytanks[tankNumber].listTank();
            cout << "What would you like to do?" << endl;
            cout << "1. Clean tank" << endl;
            cout << "2. Stabilize pH" << endl;
            cout << "3. Feed fish" << endl;
            cout << "4. Examine fish" << endl;
            cout << "5. move Fish" <<endl;
            cout << "6. move fish to new tank" <<endl;
            cout << "7. leave" << endl;
            cin >> user_response;
            if(user_response == "1"){
                bool hascleaningBrush = false;
                for(int i = 0; i < inventory.size(); i++)
                {
                    if(inventory[i].getName() == "cleaningBrush") hascleaningBrush = true;
                }
                if(hascleaningBrush){
                    one.setStamina(one.getStamina() - 2);
                    advanceHour(1);
                    mytanks[tankNumber].setCleanliness(10);
                    cout <<"You cleaned the tank." << endl; 
                }
                else cout << "You cannot clean the tank if you don't have a cleaning brush"<<endl;
            }
            if(user_response == "2"){
                int haswaterpHStabilizer = -1;
                for(int i = 0; i < inventory.size(); i++){
                    if(inventory[i].getName() == "waterpHStabilizer") haswaterpHStabilizer = i;
                }
                if(haswaterpHStabilizer != -1){
                    removeItem(haswaterpHStabilizer);
                    mytanks[tankNumber].setWaterQuality(10);
                    cout << "You stabilized the water" <<endl;
                }
                else cout << "You must have water pH stabilizer to stabilize the water pH." <<endl;
            }
            if(user_response == "3"){
                if(inventory.size() == 0) cout << "You have no items to feed your fish" <<endl;
                else{
                    displayitems(inventory);
                    cout << "Which item would you like to feed your fish?" << endl;
                    string response;
                    cin >> response;
                    if(Checknumber(response)){
                        if(stoi(response) > inventory.size() || stoi(response) == 0) cout << "invalid input" << endl;
                        else{
                            if(mytanks[tankNumber].feedFish(inventory[stoi(response)-1])) removeItem(stoi(response)-1);
                        }
                    }
                    else cout << "Invalid input" <<endl;
                }
            }
            if( user_response == "4")
            {
                mytanks[tankNumber].listFish();
            }
            if(user_response == "5")
            {
                                        
                mytanks[tankNumber].moveFish();
            }
            if(user_response == "6")
            {
                if(mytanks[tankNumber].getNumFish() == 0) cout << "You have no fish in this tank" <<endl;
                else if(mytanks.size() == 1) cout << "You only have one tank" <<endl;
                else {
                mytanks[tankNumber].listFish();
                cout << "Which fish would you like to move?" <<endl;
                cin >> user_response;
                if((!Checknumber(user_response))|| user_response.length() > 3) cout << "invalid input" <<endl;
                else if(stoi(user_response) == 0 || stoi(user_response) > mytanks[tankNumber].getNumFish()) cout<< "invalid input" <<endl;
                else
                {
                    int fishnumber = stoi(user_response) -1;
                    listTanks();
                    cout << "Which tank would you like to move the fish to?" <<endl;
                    cin >> user_response;
                    if((!Checknumber(user_response))|| user_response.length() > 3) cout << "invalid input" <<endl;
                    else if(stoi(user_response) == 0 || stoi(user_response) > mytanks.size()) cout<< "invalid input" <<endl;
                    else if(stoi(user_response) - 1 == tankNumber) cout << "This is the same tank" <<endl;
                    else{
                        if(mytanks[stoi(user_response) - 1].addFish(mytanks[tankNumber].getFish(fishnumber))) mytanks[tankNumber].removeFish(fishnumber +1);
                        else cout << "move canceled" <<endl;
                    }
                }
                }
            }
            if(user_response == "7") end = true;
        }
    }
}

void Day :: addTank(Tank Tank1)
{
    mytanks.push_back(Tank1);
}

void Day :: purchaseTank()
{
    int value = pet.buyTank(one.getMoney());
    if(value != -1){
        one.setMoney(one.getMoney() - value);
        string user_response;
        bool named = false;
        bool samename = false;
        while(named == false){
            cout << "What would you like to name this tank?" << endl;
            cin >> user_response;
            for(int i = 0; i < mytanks.size(); i++){
            if(mytanks[i].getTankName() == user_response) samename = true; 
            }
            if(samename){
               cout << "You cannot give your tank the same name as another tank" << endl;
               samename = false;
            }
            else named = true;
            
        }
        Tank Tank1(pet.tankadder(value), user_response);
        addTank(Tank1);
    }
}

void Day :: purchaseFish()
{
    int value = pet.buyFish(one.getMoney());
    if(value != -1){
        if(mytanks.size() == 0) cout << "You have no tanks to put this fish in." << endl;
        else{
            bool end = false;
            bool samename = false;
            string user_response;
            while(end == false){
                cout << "What would you like to name this fish?" << endl;
                cin >> user_response;
                for(int i = 0; i < mytanks.size(); i++)
                {
                    if(mytanks[i].hasSameName(user_response)) samename = true;
                }
                if(samename){
                    cout <<"You already have a fish with this name. Each fish must have a unique name." << endl;
                    samename = false;
                }
                else end = true;
            }
           listTanks();
           end = false;
           string tanknum;
           while(end == false){
            cout << "Which tank would you like to put " << user_response << " in?" << endl;
            cin >> tanknum;
            if(!Checknumber(tanknum)) cout << "Invalid input" << endl;
            else{
                if(stoi(tanknum) == 0 || stoi(tanknum) > mytanks.size()) cout << "Invalid input" << endl;
                else{
                    if(mytanks[stoi(tanknum) -1].addFish(pet.fishadder(value, user_response))) one.setMoney(one.getMoney() - value);
                    else cout << "purchase canceled" <<endl;
                    end = true;
                }
            }
           }
        }
    }
}

void Day ::purchasePetItem()
{
    int number = pet.purchasePetItem(one.getMoney());
    if(number != -1)
    {
        one.setMoney(one.getMoney() - pet.getItemcost(number));
        addItem(pet.getItem(number));
    }
}

int Day :: setMoney(int newmoney)
{
    one.setMoney(newmoney);
}

void Day :: purchaseMarket()
{
    int number = market.buyitem(one.getMoney());
    if(number != -1)
    {
        one.setMoney(one.getMoney() - market.marketprice(number));
        addItem(market.marketitem(number));
    }
}

void Day::playGuessGame()
{
    cout << "Best score for Guess Game: " << guessHigh <<endl;
    int score = player.numbergame();
    if(score < guessHigh){
        cout << "New Best Score!" <<endl;
        guessHigh = score;
    }
    
}

void Day :: playJeapardyDice()
{
    player.jeapardyDice();
}
void Day :: playMarbleRun()
{
    string user_response;
    int marbles;
    cout << "How many marbles do you want to play with?" << endl;
    cin >> user_response;
    if(user_response.length() > 4 || (!Checknumber(user_response))) cout << "invalid input" <<endl;
    else if(stoi(user_response) < 10) cout << "You must play with at least 10 marbles" <<endl;
    else{
    marbles = stoi(user_response);
    cout << "Do you want to play on hard or easy mode?" <<endl;
    cout << "1. easy mode" <<endl;
    cout << "2. hard mode" <<endl;
    cin >> user_response;
    if(user_response == "1") player.marbleRun(marbles,0,0);
    else if(user_response == "2") player.marbleRun(marbles,1,0);
    else cout <<"Invalid input" <<endl;
    }  
}

void Day :: loadGame(string textfile)
{
    string array1[83];
    string line;
    ifstream savelist;
    savelist.open(textfile);
    if(!savelist.is_open())cout << "There is no such file." <<endl;
    getline(savelist,line);
    if(line != "AquiriumSave") cout << "This is not a saved file for Aquirium Land" << endl;
    else{
    while(getline(savelist, line))
    {
        sPliT(line, ',', array1, 83);
        if(array1[0] == "hour") hour = stoi(array1[1]);
        if(array1[0] == "day") daynumber = stoi(array1[1]);
        if(array1[0] == "GuessHigh") guessHigh = stoi(array1[1]);
        if(array1[0] == "User"){
            one.setStamina(stoi(array1[1]));
            one.setDrowsiness(stoi(array1[2]));
            one.setMoney(stoi(array1[3]));
        }
        if(array1[0] == "settank"){
           Tank Tank1(stoi(array1[2]),array1[1]);
           Tank1.setCleanliness(stoi(array1[3]));
           Tank1.setWaterQuality(stoi(array1[4]));
           addTank(Tank1);
        }
        if(array1[0] == "arrangement"){
            for(int i = 0; i < stoi(array1[1]); i++)
            {
                mytanks[mytanks.size() - 1].setArrangementAt(i,array1[i+2]);
            }
        }
        if(array1[0] == "addFish"){
            string character = array1[3];
            Fish Fish1(array1[1],array1[2],character[0]);
            Fish1.changeFed(stoi(array1[6]));
            Fish1.changeHappiness(stoi(array1[4]));
            Fish1.changeHealth(stoi(array1[5]));
            mytanks[mytanks.size()-1].loadFish(Fish1);
        }
        if(array1[0] == "item"){
            Item Item1(array1[1]);
            for(int i = 0; i < stoi(array1[2]);i++){
                addItem(Item1);
            }
        }
        if(array1[0] == "score") score = stoi(array1[1]);
    }
    }
}

void Day :: saveGame(string savefile)
{
    ofstream savegame;
    savegame.open(savefile);
    savegame << "AquiriumSave"<<endl;
    savegame << "hour," << hour <<endl;
    savegame << "day," << daynumber <<endl;
    savegame << "GuessHigh," <<guessHigh << endl;
    savegame << "User," << one.getStamina() << "," << one.getDrowsiness() << "," << one.getMoney() << endl;
    for(int i = 0; i < mytanks.size(); i++)
    {
        savegame << "settank," << mytanks[i].getTankName() << "," << mytanks[i].getTankSize() << "," << mytanks[i].getCleanliness() << "," <<mytanks[i].getWaterQuality()<< endl;
        savegame << "arrangement," << mytanks[i].getTankSize() << ",";
        for(int j=0; j < mytanks[i].getTankSize(); j++)
        {
            savegame << mytanks[i].getArrangementAt(j) << ",";
        }
        savegame << endl;
        for(int k = 0; k < mytanks[i].getNumFish(); k++)
        {
            savegame << "addFish," << mytanks[i].getFishName(k) << "," << mytanks[i].getFishSpecies(k) << "," << mytanks[i].getFishPattern(k) << "," <<mytanks[i].getFishHappiness(k) << "," <<mytanks[i].getFishHealth(k) << "," <<mytanks[i].getFishFed(k) <<endl;
        }
    }
    for(int y = 0; y < inventory.size(); y++)
    {
        savegame << "item," << inventory[y].getName() << "," << inventory[y].getNumber() <<endl;
    }
    savegame << "score," <<score;
}

void Day :: oceans()
{
    string end = "no";
    while(end == "no")
    {
        ocean.BeachMenu();
        string user_response;
        cin >> user_response;
        if(user_response == "1")
        {
           one.setStamina(one.getStamina()-1);
           advanceHour(1);
           string itemname = ocean.scavenged();
           cout << "You found " <<itemname <<endl;
           Item Item1(itemname);
           addItem(Item1); 
        }
        else if(user_response == "2")
        {
            if(hasFishingPole()){
                one.setStamina(one.getStamina()-4);
                advanceHour(1);
                char pattern = ocean.randomchar();
                cout << "Please enter any 2 strings" <<endl;
                cin >> user_response;
                string fishingoption = ocean.fish();
                cin >> user_response;
                string species = ocean.returnSpecies();
                if(fishingoption == "nothing") cout << "You caught nothing" <<endl;
                if(fishingoption == "fish"){
                    cout << "You caught a " << species << ", pattern: " << pattern << endl;
                    while(user_response != "stop")
                    {
                        whatFishMenu();
                        cin >> user_response;
                        if(user_response == "1"){
                            cout << "Fish was released" <<endl;
                            user_response = "stop";
                        }
                        else if(user_response == "2")
                        {
                           if(mytanks.size() == 0) cout << "You have no tanks" <<endl;
                           else if(placingfish(species,pattern)) user_response = "stop";
                        }
                        else cout << "invalid input" <<endl;
                    }
                }
                if(fishingoption == "item"){
                    string itemname = ocean.item();
                    cout << "You caught a " <<itemname <<endl;
                    Item Item1(itemname);
                    addItem(Item1);
                }
            }
            else cout << "You cannot fish without a fishing pole." <<endl;
        }
        else if(user_response == "3") end = "yes";
        else cout << "Invalid Input" <<endl;
    }
}

void Day :: ponds()
{
    string end = "no";
    while(end == "no")
    {
        pond.PondMenu();
        string user_response;
        cin >> user_response;
        if(user_response == "1")
        {
           one.setStamina(one.getStamina()-1);
           advanceHour(1);
           string itemname = pond.scavenged();
           cout << "You found " <<itemname <<endl;
           Item Item1(itemname);
           addItem(Item1); 
        }
        else if(user_response == "2")
        {
            if(hasFishingPole()){
                one.setStamina(one.getStamina()-2);
                advanceHour(1);
                char pattern = pond.randomchar();
                cout << "Please enter any 2 strings" <<endl;
                cin >> user_response;
                string fishingoption = pond.fish();
                cin >> user_response;
                string species = pond.returnSpecies();
                if(fishingoption == "nothing") cout << "You caught nothing" <<endl;
                if(fishingoption == "fish"){
                    cout << "You caught a " << species << ", pattern: " << pattern << endl;
                    while(user_response != "stop")
                    {
                        whatFishMenu();
                        cin >> user_response;
                        if(user_response == "1"){
                            cout << "Fish was released" <<endl;
                            user_response = "stop";
                        }
                        else if(user_response == "2")
                        {
                           if(mytanks.size() == 0) cout << "You have no tanks" <<endl;
                           else if(placingfish(species,pattern)) user_response = "stop";
                        }
                        else cout << "invalid input" <<endl;
                    }
                }
                if(fishingoption == "item"){
                    string itemname = pond.item();
                    cout << "You caught a " <<itemname <<endl;
                    Item Item1(itemname);
                    addItem(Item1);
                }
            }
            else cout << "You cannot fish without a fishing pole." <<endl;
        }
        else if(user_response == "3") end = "yes";
        else cout << "Invalid Input" <<endl;
    }
}

void Day :: forests()
{
    string end = "no";
    while(end == "no")
    {
        forest.ForestMenu();
        string choice;
        cin >> choice;
        if(choice == "1")
        {
            one.setStamina(one.getStamina() - 1);
            advanceHour(1);
            string itemname = forest.searchForest();
            cout << "You found " << itemname <<endl;
            if(itemname == "nothing");
            else{
                Item Item1(itemname);
                addItem(Item1);
            }
        }
        else if(choice == "2") end = "yes";
        else cout << "Invalid input"<<endl;
    }
}

void Day :: sellFish()
{
    
    if(mytanks.size() == 0) cout<< "You have no tanks" <<endl;
    else{
        cout << "Which tank has the fish you would like to sell?" <<endl;
        listTanks();
        string user_response;
        cin >> user_response;
        if((!Checknumber(user_response))|| user_response.size() > 3) cout << "Invalid input" <<endl;
        else if(stoi(user_response) == 0 || stoi(user_response) > mytanks.size()) cout << "Invalid input" <<endl;
        else if(mytanks[stoi(user_response)-1].getNumFish() == 0) cout << "There are no fish in this tank" <<endl;
        else{
            int numFish = mytanks[stoi(user_response)-1].getNumFish();
            int tanknumber = stoi(user_response) - 1;
            mytanks[stoi(user_response)-1].listFish();
            cout << "Which fish would you like to sell?" <<endl;
            cin >> user_response;
            if((!Checknumber(user_response))|| user_response.size() > 3) cout << "Invalid input" <<endl;
            else if(stoi(user_response) == 0 || stoi(user_response) > numFish) cout << "Invalid input" <<endl;
            else{
                int fishnumber = stoi(user_response) -1;
                if(mytanks[tanknumber].getFishHappiness(fishnumber) < -3 ||  mytanks[tanknumber].getFishHealth(fishnumber) < -3) cout<< "You cannot sell this fish because it is in poor condition" <<endl;
                else{
                    string species = mytanks[tanknumber].getFishSpecies(fishnumber);
                    char pattern = mytanks[tanknumber].getFishPattern(fishnumber);
                    int price = pet.sellfish(species, pattern);
                    cout << "Sell " << mytanks[tanknumber].getFishName(fishnumber) << " for " << price << "g (Yes/No)?" <<endl;
                    cin >> user_response;
                    if(user_response == "Y" || user_response == "y" || user_response == "Yes" || user_response == "yes")
                    {
                        mytanks[tanknumber].removeFish(fishnumber + 1);
                        one.setMoney(one.getMoney() + price);
                        cout << "Fish sold" <<endl;
                    }
                    else cout << "Sale canceled" <<endl;
                }
            }
        }
    }
}

void Day :: sellItems()
{
    if(inventory.size() == 0) cout << "You have no items in your inventory" <<endl;
    else{
        displayitems(inventory);
        cout << "Which item would you like to sell?" <<endl;
        string user_response;
        cin >> user_response;
        if((!Checknumber(user_response))|| user_response.size() > 3) cout << "Invalid input" <<endl;
        else if(stoi(user_response) == 0 || stoi(user_response) > inventory.size()) cout << "Invalid input" <<endl;
        else{
            int itemnumber = stoi(user_response) -1;
            string itemname = inventory[itemnumber].getName();
            int price = market.sellItem(itemname);
            if(price == -1) cout << "You cannot sell this item at the market" <<endl;
            else{
                cout << "Sell " << inventory[itemnumber].getName() << " for " << price << "g (Yes/No)?" <<endl;
                cin >> user_response;
                 if(user_response == "Y" || user_response == "y" || user_response == "Yes" || user_response == "yes")
                    {
                        removeItem(itemnumber);
                        one.setMoney(one.getMoney() + price);
                        cout << "Item sold" <<endl;
                    }
                    else cout << "Sale canceled"<<endl;
            }
        }
        
    }
}

int Day :: calcrank()
{
    int rank = 0;
    for(int i = 0; i <mytanks.size(); i++)
    {
        rank = rank + (mytanks[i].getTankSize() * 50);
        for(int j = 0; j < mytanks[i].getNumFish(); j++)
        {
            string Species = mytanks[i].getFishSpecies(j);
            rank = rank + pet.sellfish(Species, '!');
        }
    }
    rank = rank + (inventory.size() * 100);
    rank = rank + (one.getMoney() / 50);
    rank = rank - guessHigh;
    score = rank;
    return rank;
    
}

bool Day :: checkSave(string savefile)
{
    if(savefile == "Aquirium2.cpp")return false;
    if(savefile == "Beach.cpp")return false;
    if(savefile == "Beach.h")return false;
    if(savefile == "Day.cpp" )return false;
    if(savefile == "Day.h")return false;
    if(savefile == "Daydriver.cpp")return false;
    if(savefile == "Fish.cpp")return false;
    if(savefile == "Fish.h")return false;
    if(savefile == "Fish_Designs.cpp")return false;
    if(savefile == "FishDesigns.txt")return false;
    if(savefile == "Fishdriver.cpp")return false;
    if(savefile == "FishInfo.txt")return false;
    if(savefile == "Foreset.cpp")return false;
    if(savefile == "Forest.h")return false;
    if(savefile == "game.cpp")return false;
    if(savefile == "game.h")return false;
    if(savefile == "Item.cpp")return false;
    if(savefile == "Item.h")return false;
    if(savefile == "Itemdriver.cpp")return false;
    if(savefile == "Itemlist.txt")return false;
    if(savefile == "Market.cpp")return false;
    if(savefile == "Market.h")return false;
    if(savefile == "PetStore.cpp")return false;
    if(savefile == "PetStore.h")return false;
    if(savefile == "Pond.cpp")return false;
    if(savefile == "Pond.h")return false;
    if(savefile == "Tank.cpp")return false;
    if(savefile == "Tank.h")return false;
    if(savefile == "Tankdriver.cpp")return false;
    if(savefile == "User.cpp")return false;
    if(savefile == "User.h")return false;
    if(savefile == "Userdriver.cpp")return false;
    return true;
}
int Day :: getScore()
{
    return score;
}
