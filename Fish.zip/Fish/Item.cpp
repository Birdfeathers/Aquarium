#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#include "Item.h"

int sPlit(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;
    
}

Item :: Item(string itemname)
{
    itemName = itemname;
    string array1[4];
    string line;
    ifstream Itemlist;
    Itemlist.open("Itemlist.txt");
    while(getline(Itemlist, line))
    {
        sPlit(line, ';', array1, 4);
        if(array1[0]== itemName)
        {
           if(array1[1] == "edible") edible = true;
           else edible = false;
           type = array1[2];
           foodnumber = stoi(array1[3]);
        }
    }
    number = 1;
}

bool Item :: getEdible()
{
    return edible;
}

string Item :: getName()
{
    return itemName;
}

void Item :: setNumber(int newNumber)
{
    number = newNumber;
}

int Item:: getNumber()
{
    return number;
}

string Item :: getType()
{
    return type;
}

int Item :: getFoodNumber()
{
    return foodnumber;
}