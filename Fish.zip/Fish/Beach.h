#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
using namespace std;
#ifndef BEACH_H
#define BEACH_H

class Beach
{
    public:
        void BeachMenu();
        char randomchar();
        string returnSpecies();
        string fish();
        string item();
        string scavenged();

};

#endif