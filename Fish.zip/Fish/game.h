#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#ifndef GAME
#define GAME_H
using namespace std;

class game
{
   public:
    int numbergame();
    void jeapardyDice();
    void marbleRun(int marbles, bool compmode, bool turn);
};
#endif