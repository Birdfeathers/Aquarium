#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include "PetStore.h"
#include "Fish.h"
#include "Item.h"
#include "Tank.h"
using namespace std;

bool CheckNumb(string string1)
{
    for(int i = 0; i < string1.length(); i++)
    {
        if(!isdigit(string1[i]))return false;
    }
    return true;
}

 void TankMenu(){
     cout << "Which tank would you like to buy?" << endl;
     cout << "1. Fishbowl: size 1, a 1x1 tank, 50g" << endl;
     cout << "2. Small tank: size 3, a 1x3 tank, 200g" << endl;
     cout << "3. Medium tank: size 6, a 2x3 tank 400g" << endl;
     cout << "4. Large tank: size 9, a 3x3 tank 600g" <<endl;
     cout << "5. Giant tank: size 27, a 9x3 tank, 1800g" <<endl;
     cout << "6. Personal pond: size 81, a 27x3 personal pond, 6000g" <<endl;
     cout << "7. nevermind" <<endl;
 }
 
void FishMenu(){
    cout << "Which fish would you like to buy?" << endl;
    cout << "1. goldfish with 'o' pattern. Requires a 1x1 space. Eats almost anything. 10g" << endl;
    cout << "2. MediumPacificKelpMuncher with '<' pattern. Requires a 1x2 space. Eats Greens. 50g" << endl;
    cout << "3. Seahorse with '*' pattern. Requires a  3x1 space. Eats Seafood. 300g" <<endl;
    cout << "4. Pacu with '{' pattern. Requires a 3x3 space. Eats Fruit and Nuts. 1000g" <<endl;
    cout << "5. nevermind" <<endl;
}

void ItemMenu(){
    cout << "Which item would you like to buy?" << endl;
    cout << "1. brineShrimp, 10g" << endl;
    cout << "2. cleaningBrush, 20g" << endl;
    cout << "3. waterpHStabilizer, 10g" << endl;
    cout << "4. nevermind" << endl;
}

int PetStore :: buyTank(int money)
{
    TankMenu();
    string user_response;
    cin >> user_response;
    if(CheckNumb(user_response)){
        switch(stoi(user_response)){
            case 1:
                if(money < 50){
                     cout << "You do not have enough money to buy a fishbowl" << endl;
                     cout << "Money: " << money << "g" <<endl;
                     return -1;
                }
                else return 50;
            break;
            case 2:
                if(money < 200){
                    cout << "You do not have enough money to buy a small Tank" << endl;
                    cout << "Money: " << money << "g" <<endl;
                    return -1;
                }
                else return 200;
            break;
            case 3:
                if(money < 400){
                    cout << "You do not have enough money to buy a medium Tank" << endl;
                    cout << "Money: " << money << "g" <<endl;
                    return -1;
                }
                else return 400;
            break;
            case 4:
              if(money < 600){
                    cout << "You do not have enough money to buy a large Tank" << endl;
                    cout << "Money: " << money << "g" <<endl;
                    return -1;
                }
                else return 600;
            break;
            case 5:
                if(money < 1800){
                    cout << "You do not have enough money to buy a giant Tank" << endl;
                    cout << "Money: " << money << "g" <<endl;
                    return -1;
                }
                else return 1800;
            break;
            case 6:
                if(money < 6000){
                    cout << "You do not have enough money to buy a personal pond" << endl;
                    cout << "Money: " << money << "g" <<endl;
                    return -1;
                }
                else return 6000;
            break;
            case 7:
                cout << "too bad" <<endl;
                return -1;
            break;
            default:
                cout << "Invalid input" << endl;
                return -1;
        }
        
    }
    else cout << "Invalid input" <<endl;
    return -1;
}

int PetStore :: tankadder(int cost)
{
    switch(cost){
        case 50:
            return 1;
        case 200:
            return 3;
        case 400:
            return 6;
        case 600:
            return 9;
        case 1800:
            return 27;
        case 6000:
            return 81;
    }
}

int PetStore :: buyFish(int money)
{
    FishMenu();
    string user_response;
    cin >> user_response;
    if(CheckNumb(user_response)){
        switch(stoi(user_response)){
            case 1:
                if(money < 10){
                     cout << "You do not have enough money to buy a goldfish" << endl;
                     cout << "Money: " << money << "g" <<endl;
                     return -1;
                }
                else return 10;
            break;
            case 2:
                if(money < 50){
                     cout << "You do not have enough money to buy a MediumPacificKelpMuncher" << endl;
                     cout << "Money: " << money << "g" <<endl;
                     return -1;
                }
                else return 50;
            break;
            case 3:
                if(money < 300){
                     cout << "You do not have enough money to buy a Seahorse" << endl;
                     cout << "Money: " << money << "g" <<endl;
                     return -1;
                }
                else return 300;
            break;
            case 4:
                if(money < 1000){
                     cout << "You do not have enough money to buy a Pacu" << endl;
                     cout << "Money: " << money << "g" <<endl;
                     return -1;
                }
                else return 1000;
            break;
            case 5:
                cout << "too bad" << endl;
                return -1;
            break;
            default:
                cout << "Invalid input" << endl;
                return -1;
            
        }
    }
    else cout << "Invalid input" <<endl;
    return -1;
    
}

Fish PetStore :: fishadder(int cost, string name)
{
    Fish goldy(name, "goldfish", 'o');
    Fish munchy(name, "MediumPacificKelpMuncher", '<');
    Fish horsey(name, "Seahorse", '*');
    Fish packy(name, "Pacu", '{');
    switch(cost)
    {
        case 10:
            return goldy;
        case 50:
            return munchy;
        case 300:
            return horsey;
        case 1000:
            return packy;
    }
}

int PetStore :: purchasePetItem(int money)
{
    ItemMenu();
    string user_response;
    cin >> user_response;
    if(CheckNumb(user_response)){
        switch(stoi(user_response)){
            case 1:if(money < 10){
                     cout << "You do not have enough money to buy brineShrimp" << endl;
                     cout << "Money: " << money << "g" <<endl;
                     return -1;
                }
                else return stoi(user_response);
            break;
            case 2:if(money < 20){
                     cout << "You do not have enough money to buy cleaningBrush" << endl;
                     cout << "Money: " << money << "g" <<endl;
                     return -1;
                }
                else return stoi(user_response);
            break;
             case 3:if(money < 10){
                     cout << "You do not have enough money to buy waterpHStabilizer" << endl;
                     cout << "Money: " << money << "g" <<endl;
                     return -1;
                }
                else return stoi(user_response);
            break;
            case 4:
                cout << "too bad" << endl;
                return -1;
            break;
            default:
                cout << "Invalid input" << endl;
                return -1;
        }
    }
    else cout << "Invalid input" <<endl;
    return -1;
    
}

int PetStore :: getItemcost(int number)
{
    if(number == 1) return 10;
    if(number == 2) return 20;
    if(number == 3) return 10;
}

Item PetStore :: getItem(int number)
{
    Item shrimp("brineShrimp");
    Item brush("cleaningBrush");
    Item pH("waterpHStabilizer");
    if(number == 1){
        cout << "You purchased brineShrimp" <<endl;
        return shrimp;
    }
    if(number == 2){
        cout << "You purchased cleaningBrush." <<endl;
        return brush;
    }
    if(number == 3){
        cout << "You purchased waterpHStabilizer." <<endl;
        return pH;
    }
    
}

int PetStore :: sellfish(string species, char pattern)
{
    if(species == "goldfish"){
        if(pattern == 'o') return 5;
        else return 10;
    }
    if(species == "MediumPacificKelpMuncher"){
        if(pattern == '<') return 25;
        else return 50;
    }
    if(species == "Seahorse"){
        if(pattern == '*') return 150;
        else return 300;
    }
    if(species == "Pacu"){
        if(pattern == '{') return 500;
        else return 1000;
    }
    if(species == "SeaTurtle") return 2000;
    if(species == "Barracuda") return 1000;
    if(species == "guppy") return 20;
    if(species == "BetaFish") return 50;
    if(species == "LakeMonster") return 10000;
    if(species == "TigerShark") return 5000;
    if(species == "BoxTurtle") return 2000;
}