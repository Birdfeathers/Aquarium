#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Beach.h"
#include "Fish.h"
#include "Item.h"
#include "Market.h"
#include "PetStore.h"
#include "Pond.h"
#include "Tank.h"
#include "User.h"
#include "Day.h"
#include "Forest.h"
using namespace std;

int main()
{
    // Item Item0("apple");
    // Item Item2("apple");
    // Item Item3("lettuce");
    // Item Item4("fishingPole");
    // Item Item5("acorn");
    // Item Item6("apple");
    // Item Item7("walnut");
    // Item Item8("lettuce");
    // Item Item9("cleaningBrush");
    // Item Item10("waterpHStabilizer");
    Tank tanky(3, "tanky");
    // Fish Ian("Ian", "goldfish", 'b');
    // Fish Daniel("Daniel", "MediumPacificKelpMuncher", '8');
    // tanky.addFish(Ian);
    // tanky.addFish(Daniel);
    // cout << Item3.getName() <<endl;
    // cout << Item6.getName() <<endl;
    Day one;
    one.addTank(tanky);
    // cout << one.addItem(Item0) <<endl;
    // cout << one.addItem(Item2) << endl;
    // cout << one.addItem(Item3) <<endl;
    // cout << one.addItem(Item4) <<endl;
    // cout << one.addItem(Item5) <<endl;
    // cout << one.addItem(Item6) <<endl;
    // cout << one.addItem(Item7) <<endl;
    // cout << one.addItem(Item8) <<endl;
    // cout << one.addItem(Item9) <<endl;
    // cout << one.addItem(Item10) <<endl;
    // // one.removeItem(4);
    // // one.removeItem(0);
    // //one.removeItem(1);
    // //one.removeItem(1);
    // //cout << one.checkInventory() << endl;
    // // tanky.feedFish(Item0);
    // // tanky.feedFish(Item2);
    // // tanky.feedFish(Item7);
    // // tanky.feedFish(Item4);
    // one.examineTank(0);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(24);
    // one.advanceHour(70);
    // cout << "The day is " <<one.getDay() <<endl;
    // one.examineTank(0);
    
    cout << one.placingfish("goldfish", 'y');
    
}