#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include "Item.h"
using namespace std;
#ifndef MARKET_H
#define MARKET_H

class Market
{
    public:
        int buyitem(int money);
        int marketprice(int number);
        Item marketitem(int number);
        int sellItem(string itemname);
        
};
#endif